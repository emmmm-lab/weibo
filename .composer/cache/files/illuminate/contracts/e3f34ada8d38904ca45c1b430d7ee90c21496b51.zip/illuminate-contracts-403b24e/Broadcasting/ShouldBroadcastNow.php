<?php

namespace Illuminate\Contracts\Broadcasting;

interface ShouldBroadcastNow extends ShouldBroadcast
{
    //
}
